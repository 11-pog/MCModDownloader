# Minecraft Mod Downloader

A Python script to download Minecraft mods from Modrinth and Curseforge automatically.
Supports single mod downloads, batch downloads from a list, and dependency resolution (Auto download still WIP (i dont even know if i will actually finish it lmao))

## Disclaimer

We're not responsible for any damage caused by this lib, including but not limited to:

- Loss of productivity
- Brain damage caused by bad code
- PseudoComa
- Spontaneous combustion
- High doses of radiation poisoning
- Deep Root Disease
- Non-Existence
- Enlightment
- *Death*

## License and Copyright Information

### Copyright

This shit is copyrighted by who knows and is licensed by absolutely no one lmfao
